import React, { Component } from 'react';

class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: ''
        }
    }
    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }
    onSubmit = (e) => {
        e.preventDefault();
        this.props.setUser(this.state.user)
    }
    render() {
        return (
            <div className="col-md-12">
                <form onSubmit ={this.onSubmit}> 
                    <div className="form-group">
                        <label> Enter name </label>
                        <input className="form-control" name="user" onChange={this.onChange} required/>
                        <br />
                        <input type="submit" className="btn btn-primary" value="enter" onChange={this.onChange}/>
                    </div>
                </form>
            </div>
        )
    }
}
export default Form;